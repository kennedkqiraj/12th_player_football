library(plyr)
library(readr)
library(dplyr)
library(data.table)
library(lubridate)
library(stringr)
library(ggplot2)
library(tidyr)
library(ggplot2)
#install.packages("reshape2")
library(reshape2)

# Read the combined_data.csv file from the Data subfolder into a data frame named d.EPL
d.EPL <- read.csv(file = "Data/combined_data.csv")

# Calculate Home Booking Points (HBP) based on yellow and red cards for the home team
d.EPL$HBP <- (d.EPL$HY * 10) + (d.EPL$HR * 25)

# Calculate Away Booking Points (ABP) based on yellow and red cards for the away team
d.EPL$ABP <- (d.EPL$AY * 10) + (d.EPL$AR * 25)

# Display the first few rows of the updated data frame to verify
head(d.EPL)

#######################################################################################################
#Filtering for covid dates:

# Convert DATE column to Date format
d.EPL$DATE <- as.Date(d.EPL$DATE, format = "%d/%m/%y")

# Create a column to flag games with no crowd attendance
d.EPL$No_Crowd <- ifelse(
  (d.EPL$DATE >= as.Date("2020-06-17") & d.EPL$DATE <= as.Date("2020-07-26")) |  # Project Restart
    (d.EPL$DATE >= as.Date("2020-09-12") & d.EPL$DATE <= as.Date("2020-12-01")) |  # 2020-21 start to limited crowds
    (d.EPL$DATE >= as.Date("2020-12-17") & d.EPL$DATE <= as.Date("2021-05-16")),   # No crowds after restrictions returned
  TRUE, FALSE
)

# Create a column to flag games with limited crowd attendance
d.EPL$Limited_Crowd <- ifelse(
  (d.EPL$DATE >= as.Date("2020-12-02") & d.EPL$DATE <= as.Date("2020-12-16")) |  # Brief limited crowds in December 2020
    (d.EPL$DATE >= as.Date("2021-05-17") & d.EPL$DATE <= as.Date("2021-05-23")),   # Final two matchweeks with limited crowds
  TRUE, FALSE
)

# Display games with No Crowd or Limited Crowd flags
head(d.EPL[c("DATE", "HOMETEAM", "AWAYTEAM", "No_Crowd", "Limited_Crowd")])




#######################################################################################################
####################      Home vs. Away Fouls       ###############################################################

# # Ensure that the 'Win_Diff' is properly represented with positive and negative values
# d.EPL$Win_Diff <- d.EPL$Home_Win_Rate - d.EPL$Away_Win_Rate
# 
# # Create a bar plot
# library(ggplot2)
# 
# ggplot(d.EPL, aes(x = reorder(Team, d.EPL), y = d.EPL, fill = d.EPL > 0)) +
#   geom_bar(stat = "identity") +
#   coord_flip() +  # Flip to make horizontal bars
#   geom_vline(xintercept = 0, linetype = "dashed", color = "black") +  # Vertical line at x = 0
#   scale_fill_manual(values = c("red", "blue"), labels = c("Away Wins More", "Home Wins More")) +  # Red for Away win more, Blue for Home win more
#   labs(title = "Home vs Away Win Rate Difference per Team",
#        x = "Team",
#        y = "Win Rate Difference (Home - Away)",
#        fill = "Win Diff") +
#   theme_minimal()

#######################################################################################################
#Yellow Cards Total
# Calculate total yellow cards per team (home and away)
total_home_yellow_cards <- tapply(d.EPL$HY, d.EPL$HOMETEAM, sum, na.rm = TRUE)
total_away_yellow_cards <- tapply(d.EPL$AY, d.EPL$AWAYTEAM, sum, na.rm = TRUE)

# Create a vector of all teams (union of home and away teams)
all_teams <- unique(c(names(total_home_yellow_cards), names(total_away_yellow_cards)))

# Ensure all teams are present in the yellow card counts
total_home_yellow_cards <- total_home_yellow_cards[all_teams]
total_home_yellow_cards[is.na(total_home_yellow_cards)] <- 0

total_away_yellow_cards <- total_away_yellow_cards[all_teams]
total_away_yellow_cards[is.na(total_away_yellow_cards)] <- 0

# Calculate the percentage difference in yellow cards (Away - Home)
yellow_card_diff <- (total_away_yellow_cards - total_home_yellow_cards) / 
  (total_home_yellow_cards + total_away_yellow_cards) * 100

# Create a data frame for plotting
yellow_cards_df <- data.frame(
  Team = all_teams,
  Yellow_Card_Diff = yellow_card_diff
)

# Plot the percentage difference in yellow cards
library(ggplot2)

ggplot(yellow_cards_df, aes(x = reorder(Team, Yellow_Card_Diff), y = Yellow_Card_Diff, fill = Yellow_Card_Diff > 0)) +
  geom_bar(stat = "identity") +
  coord_flip() +  # Flip to make horizontal bars
  geom_vline(xintercept = 0, linetype = "dashed", color = "black") +  # Vertical line at x = 0
  scale_fill_manual(values = c("blue", "red"), labels = c("Home Cards More", "Away Cards More")) +  # Blue for Home cards more, Red for Away cards more
  labs(title = "Percentage Difference in Yellow Cards (Away vs Home) per Team",
       x = "Team",
       y = "Percentage Difference in Yellow Cards (Away - Home)",
       fill = "Card Diff") +
  theme_minimal()




#######################################################################################################

# Assuming you already have No_Crowd and Limited_Crowd flags in d.EPL

# Filter data for no crowd games
no_crowd_data <- d.EPL[d.EPL$No_Crowd == TRUE, ]

# Filter data for games with crowd restrictions lifted (limited crowds)
limited_crowd_data <- d.EPL[d.EPL$Limited_Crowd == TRUE, ]

# Define a function to calculate yellow card percentage differences and plot
plot_yellow_card_diff <- function(data, period_title) {
  # Calculate total yellow cards per team (home and away)
  total_home_yellow_cards <- tapply(data$HY, data$HOMETEAM, sum, na.rm = TRUE)
  total_away_yellow_cards <- tapply(data$AY, data$AWAYTEAM, sum, na.rm = TRUE)
  
  # Create a vector of all teams (union of home and away teams)
  all_teams <- unique(c(names(total_home_yellow_cards), names(total_away_yellow_cards)))
  
  # Ensure all teams are present in the yellow card counts
  total_home_yellow_cards <- total_home_yellow_cards[all_teams]
  total_home_yellow_cards[is.na(total_home_yellow_cards)] <- 0
  
  total_away_yellow_cards <- total_away_yellow_cards[all_teams]
  total_away_yellow_cards[is.na(total_away_yellow_cards)] <- 0
  
  # Calculate the percentage difference in yellow cards (Away - Home)
  yellow_card_diff <- (total_away_yellow_cards - total_home_yellow_cards) / 
    (total_home_yellow_cards + total_away_yellow_cards) * 100
  
  # Create a data frame for plotting
  yellow_cards_df <- data.frame(
    Team = all_teams,
    Yellow_Card_Diff = yellow_card_diff
  )
  
  # Plot the percentage difference in yellow cards
  ggplot(yellow_cards_df, aes(x = reorder(Team, Yellow_Card_Diff), y = Yellow_Card_Diff, fill = Yellow_Card_Diff > 0)) +
    geom_bar(stat = "identity") +
    coord_flip() +  # Flip to make horizontal bars
    geom_vline(xintercept = 0, linetype = "dashed", color = "black") +  # Vertical line at x = 0
    scale_fill_manual(values = c("blue", "red"), labels = c("Home Cards More", "Away Cards More")) +  # Blue for Home cards more, Red for Away cards more
    labs(title = paste("Percentage Difference in Yellow Cards (Away vs Home) -", period_title),
         x = "Team",
         y = "Percentage Difference in Yellow Cards (Away - Home)",
         fill = "Card Diff") +
    theme_minimal()
}

# Plot for No Crowd Period
plot_yellow_card_diff(no_crowd_data, "No Crowd Period")

# Plot for Limited Crowd Period
plot_yellow_card_diff(limited_crowd_data, "Limited Crowd Period")

#######################################################################################################

# Filter data for periods with no restrictions (both No_Crowd and Limited_Crowd are FALSE)
normal_crowd_data <- d.EPL[d.EPL$No_Crowd == FALSE & d.EPL$Limited_Crowd == FALSE, ]

# Define the same function to calculate yellow card percentage differences and plot
plot_yellow_card_diff <- function(data, period_title) {
  # Calculate total yellow cards per team (home and away)
  total_home_yellow_cards <- tapply(data$HY, data$HOMETEAM, sum, na.rm = TRUE)
  total_away_yellow_cards <- tapply(data$AY, data$AWAYTEAM, sum, na.rm = TRUE)
  
  # Create a vector of all teams (union of home and away teams)
  all_teams <- unique(c(names(total_home_yellow_cards), names(total_away_yellow_cards)))
  
  # Ensure all teams are present in the yellow card counts
  total_home_yellow_cards <- total_home_yellow_cards[all_teams]
  total_home_yellow_cards[is.na(total_home_yellow_cards)] <- 0
  
  total_away_yellow_cards <- total_away_yellow_cards[all_teams]
  total_away_yellow_cards[is.na(total_away_yellow_cards)] <- 0
  
  # Calculate the percentage difference in yellow cards (Away - Home)
  yellow_card_diff <- (total_away_yellow_cards - total_home_yellow_cards) / 
    (total_home_yellow_cards + total_away_yellow_cards) * 100
  
  # Create a data frame for plotting
  yellow_cards_df <- data.frame(
    Team = all_teams,
    Yellow_Card_Diff = yellow_card_diff
  )
  
  # Plot the percentage difference in yellow cards
  ggplot(yellow_cards_df, aes(x = reorder(Team, Yellow_Card_Diff), y = Yellow_Card_Diff, fill = Yellow_Card_Diff > 0)) +
    geom_bar(stat = "identity") +
    coord_flip() +  # Flip to make horizontal bars
    geom_vline(xintercept = 0, linetype = "dashed", color = "black") +  # Vertical line at x = 0
    scale_fill_manual(values = c("blue", "red"), labels = c("Home Cards More", "Away Cards More")) +  # Blue for Home cards more, Red for Away cards more
    labs(title = paste("Percentage Difference in Yellow Cards (Away vs Home) -", period_title),
         x = "Team",
         y = "Percentage Difference in Yellow Cards (Away - Home)",
         fill = "Card Diff") +
    theme_minimal()
}

# Plot for Normal Crowd Period (No restrictions)
plot_yellow_card_diff(normal_crowd_data, "No Crowd Restrictions Period")

######################################################################################################
##Red Cards
# Define a function to calculate red card percentage differences and plot
plot_red_card_diff <- function(data, period_title) {
  # Calculate total red cards per team (home and away)
  total_home_red_cards <- tapply(data$HR, data$HOMETEAM, sum, na.rm = TRUE)
  total_away_red_cards <- tapply(data$AR, data$AWAYTEAM, sum, na.rm = TRUE)
  
  # Create a vector of all teams (union of home and away teams)
  all_teams <- unique(c(names(total_home_red_cards), names(total_away_red_cards)))
  
  # Ensure all teams are present in the red card counts
  total_home_red_cards <- total_home_red_cards[all_teams]
  total_home_red_cards[is.na(total_home_red_cards)] <- 0
  
  total_away_red_cards <- total_away_red_cards[all_teams]
  total_away_red_cards[is.na(total_away_red_cards)] <- 0
  
  # Calculate the percentage difference in red cards (Away - Home)
  red_card_diff <- (total_away_red_cards - total_home_red_cards) / 
    (total_home_red_cards + total_away_red_cards) * 100
  
  # Create a data frame for plotting
  red_cards_df <- data.frame(
    Team = all_teams,
    Red_Card_Diff = red_card_diff
  )
  
  # Plot the percentage difference in red cards
  ggplot(red_cards_df, aes(x = reorder(Team, Red_Card_Diff), y = Red_Card_Diff, fill = Red_Card_Diff > 0)) +
    geom_bar(stat = "identity") +
    coord_flip() +  # Flip to make horizontal bars
    geom_vline(xintercept = 0, linetype = "dashed", color = "black") +  # Vertical line at x = 0
    scale_fill_manual(values = c("blue", "red"), labels = c("Home Cards More", "Away Cards More")) +  # Blue for Home cards more, Red for Away cards more
    labs(title = paste("Percentage Difference in Red Cards (Away vs Home) -", period_title),
         x = "Team",
         y = "Percentage Difference in Red Cards (Away - Home)",
         fill = "Card Diff") +
    theme_minimal()
}

# Plot for No Crowd Period
plot_red_card_diff(no_crowd_data, "No Crowd Period")

# Plot for Limited Crowd Period
plot_red_card_diff(limited_crowd_data, "Limited Crowd Period")

# Plot for Normal Crowd Period (No restrictions)
plot_red_card_diff(normal_crowd_data, "No Crowd Restrictions Period")

####################################################################################################
#Number of fouls
# Define a function to calculate fouls percentage differences and plot
plot_foul_diff <- function(data, period_title) {
  # Calculate total fouls per team (home and away)
  total_home_fouls <- tapply(data$HF, data$HOMETEAM, sum, na.rm = TRUE)
  total_away_fouls <- tapply(data$AF, data$AWAYTEAM, sum, na.rm = TRUE)
  
  # Create a vector of all teams (union of home and away teams)
  all_teams <- unique(c(names(total_home_fouls), names(total_away_fouls)))
  
  # Ensure all teams are present in the fouls counts
  total_home_fouls <- total_home_fouls[all_teams]
  total_home_fouls[is.na(total_home_fouls)] <- 0
  
  total_away_fouls <- total_away_fouls[all_teams]
  total_away_fouls[is.na(total_away_fouls)] <- 0
  
  # Calculate the percentage difference in fouls (Away - Home)
  foul_diff <- (total_away_fouls - total_home_fouls) / 
    (total_home_fouls + total_away_fouls) * 100
  
  # Create a data frame for plotting
  fouls_df <- data.frame(
    Team = all_teams,
    Foul_Diff = foul_diff
  )
  
  # Plot the percentage difference in fouls
  ggplot(fouls_df, aes(x = reorder(Team, Foul_Diff), y = Foul_Diff, fill = Foul_Diff > 0)) +
    geom_bar(stat = "identity") +
    coord_flip() +  # Flip to make horizontal bars
    geom_vline(xintercept = 0, linetype = "dashed", color = "black") +  # Vertical line at x = 0
    scale_fill_manual(values = c("blue", "red"), labels = c("Home Fouls More", "Away Fouls More")) +  # Blue for Home fouls more, Red for Away fouls more
    labs(title = paste("Percentage Difference in Fouls Committed (Away vs Home) -", period_title),
         x = "Team",
         y = "Percentage Difference in Fouls (Away - Home)",
         fill = "Foul Diff") +
    theme_minimal()
}

# Plot for No Crowd Period
plot_foul_diff(no_crowd_data, "No Crowd Period")

# Plot for Limited Crowd Period
plot_foul_diff(limited_crowd_data, "Limited Crowd Period")

# Plot for Normal Crowd Period (No restrictions)
plot_foul_diff(normal_crowd_data, "No Crowd Restrictions Period")



#######################################################################################################

# Calculate total home games per team
total_home_games <- table(d.EPL$HOMETEAM)

# Calculate total away games per team
total_away_games <- table(d.EPL$AWAYTEAM)

# Calculate home wins per team
home_wins <- table(d.EPL$HOMETEAM[d.EPL$FTR == "H"])

# Calculate away wins per team
away_wins <- table(d.EPL$AWAYTEAM[d.EPL$FTR == "A"])

# Create a vector of all teams (union of home and away teams)
all_teams <- unique(c(names(total_home_games), names(total_away_games)))

# Ensure all teams are present in home_wins and away_wins
home_wins <- home_wins[all_teams]
home_wins[is.na(home_wins)] <- 0

away_wins <- away_wins[all_teams]
away_wins[is.na(away_wins)] <- 0

# Ensure all teams are present in total_home_games and total_away_games
total_home_games <- total_home_games[all_teams]
total_home_games[is.na(total_home_games)] <- 0

total_away_games <- total_away_games[all_teams]
total_away_games[is.na(total_away_games)] <- 0

# Calculate home win rate per team
home_win_rate <- home_wins / total_home_games

# Calculate away win rate per team
away_win_rate <- away_wins / total_away_games

# Combine into a data frame
win_rates <- data.frame(
  Team = all_teams,
  Home_Win_Rate = as.numeric(home_win_rate),
  Away_Win_Rate = as.numeric(away_win_rate)
)

print(win_rates)
###########################################################################
library(ggplot2)
# Melt the data frame to long format for ggplot2
library(reshape2)
win_rates_long <- melt(win_rates, id.vars = "Team", 
                       variable.name = "Win_Type", 
                       value.name = "Win_Rate")

# Create a grouped bar plot
combined_plot <- ggplot(win_rates_long, aes(x = reorder(Team, -Win_Rate), y = Win_Rate, fill = Win_Type)) +
  geom_bar(stat = "identity", position = "dodge") +
  coord_flip() +
  labs(title = "Home and Away Win Rates per Team", x = "Team", y = "Win Rate") +
  scale_fill_manual(values = c("Home_Win_Rate" = "skyblue", "Away_Win_Rate" = "orange"),
                    labels = c("Home Win Rate", "Away Win Rate")) +
  theme_minimal()

# Display the plot
print(combined_plot)
###########################################################################

# Calculate total home yellow cards per team
home_yellow_cards <- tapply(d.EPL$HY, d.EPL$HOMETEAM, sum, na.rm = TRUE)

# Calculate total away yellow cards per team
away_yellow_cards <- tapply(d.EPL$AY, d.EPL$AWAYTEAM, sum, na.rm = TRUE)

# Calculate total home red cards per team
home_red_cards <- tapply(d.EPL$HR, d.EPL$HOMETEAM, sum, na.rm = TRUE)

# Calculate total away red cards per team
away_red_cards <- tapply(d.EPL$AR, d.EPL$AWAYTEAM, sum, na.rm = TRUE)

# Create a vector of all teams (union of home and away teams)
all_teams <- unique(c(names(home_yellow_cards), names(away_yellow_cards), names(home_red_cards), names(away_red_cards)))

# Ensure all teams are present in the card counts
home_yellow_cards <- home_yellow_cards[all_teams]
home_yellow_cards[is.na(home_yellow_cards)] <- 0

away_yellow_cards <- away_yellow_cards[all_teams]
away_yellow_cards[is.na(away_yellow_cards)] <- 0

home_red_cards <- home_red_cards[all_teams]
home_red_cards[is.na(home_red_cards)] <- 0

away_red_cards <- away_red_cards[all_teams]
away_red_cards[is.na(away_red_cards)] <- 0

# Combine into a data frame
cards_comparison <- data.frame(
  Team = all_teams,
  Home_Yellow_Cards = as.numeric(home_yellow_cards),
  Away_Yellow_Cards = as.numeric(away_yellow_cards),
  Home_Red_Cards = as.numeric(home_red_cards),
  Away_Red_Cards = as.numeric(away_red_cards)
)

print(cards_comparison)


######################################################################################


# Calculate total yellow cards per team
cards_comparison$Total_Yellow_Cards <- cards_comparison$Home_Yellow_Cards + cards_comparison$Away_Yellow_Cards

# Calculate percentage of yellow cards at home and away
cards_comparison$Home_Yellow_Percentage <- (cards_comparison$Home_Yellow_Cards / cards_comparison$Total_Yellow_Cards) * 100
cards_comparison$Away_Yellow_Percentage <- (cards_comparison$Away_Yellow_Cards / cards_comparison$Total_Yellow_Cards) * 100

# Subset the data to include only percentages
yellow_cards_percentage <- cards_comparison[, c("Team", "Home_Yellow_Percentage", "Away_Yellow_Percentage")]

# Convert data to long format
yellow_cards_long <- melt(yellow_cards_percentage, id.vars = "Team", 
                          variable.name = "Card_Type", 
                          value.name = "Percentage")



# Calculate total yellow cards and percentages
cards_comparison$Total_Yellow_Cards <- cards_comparison$Home_Yellow_Cards + cards_comparison$Away_Yellow_Cards
cards_comparison$Home_Yellow_Percentage <- (cards_comparison$Home_Yellow_Cards / cards_comparison$Total_Yellow_Cards) * 100
cards_comparison$Away_Yellow_Percentage <- (cards_comparison$Away_Yellow_Cards / cards_comparison$Total_Yellow_Cards) * 100

# Melt the data frame to long format for percentages
cards_long <- melt(cards_comparison[, c("Team", "Home_Yellow_Percentage", "Away_Yellow_Percentage")], 
                   id.vars = "Team", 
                   variable.name = "Card_Type", 
                   value.name = "Percentage")

# Grouped bar plot for percentages
ggplot(cards_long, aes(x = reorder(Team, -Percentage), y = Percentage, fill = Card_Type)) +
  geom_bar(stat = "identity", position = "dodge") +
  coord_flip() +
  labs(title = "Percentage of Yellow Cards (Home vs. Away) per Team",
       x = "Team", y = "Percentage (%)") +
  scale_fill_manual(values = c("Home_Yellow_Percentage" = "yellow", 
                               "Away_Yellow_Percentage" = "darkgoldenrod")) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


###############################################################################
# Calculate total red cards and percentages
cards_comparison$Total_Red_Cards <- cards_comparison$Home_Red_Cards + cards_comparison$Away_Red_Cards
cards_comparison$Home_Red_Percentage <- (cards_comparison$Home_Red_Cards / cards_comparison$Total_Red_Cards) * 100
cards_comparison$Away_Red_Percentage <- (cards_comparison$Away_Red_Cards / cards_comparison$Total_Red_Cards) * 100

# Melt the data frame to long format for percentages
cards_long_red <- melt(cards_comparison[, c("Team", "Home_Red_Percentage", "Away_Red_Percentage")], 
                       id.vars = "Team", 
                       variable.name = "Card_Type", 
                       value.name = "Percentage")

# Grouped bar plot for red card percentages
ggplot(cards_long_red, aes(x = reorder(Team, -Percentage), y = Percentage, fill = Card_Type)) +
  geom_bar(stat = "identity", position = "dodge") +
  coord_flip() +
  labs(title = "Percentage of Red Cards (Home vs. Away) per Team",
       x = "Team", y = "Percentage (%)") +
  scale_fill_manual(values = c("Home_Red_Percentage" = "red", 
                               "Away_Red_Percentage" = "darkred")) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


#################################################################


write.csv(d.EPL, file = "data_for_Shiny.csv", row.names = FALSE)

###########################################################################################################
#Shiny
###########################################################################################################

#install.packages("fastmap")

library(shiny)
library(ggplot2)
library(dplyr)
library(reshape2)

# Load the data
d.EPL <- read.csv("Data/combined_data.csv")

# Convert DATE column to Date format
d.EPL$DATE <- as.Date(d.EPL$DATE, format = "%d/%m/%y")

# Shiny UI
ui <- fluidPage(
  titlePanel("EPL Stats Dashboard"),
  sidebarLayout(
    sidebarPanel(
      # Dropdown menu for selecting the metric to plot
      selectInput(
        inputId = "metric", 
        label = "Select a metric to plot:", 
        choices = c("Yellow Cards", "Red Cards", "Fouls"),
        selected = "Yellow Cards"
      )
    ),
    mainPanel(
      # Output the plot
      plotOutput(outputId = "metricPlot")
    )
  )
)

# Shiny Server
server <- function(input, output) {
  
  # Render the plot based on the selected metric
  output$metricPlot <- renderPlot({
    
    # Subset the data based on the selected metric
    if (input$metric == "Fouls") {
      # Calculate percentage difference in fouls (Away - Home)
      data <- d.EPL %>%
        group_by(HOMETEAM) %>%
        summarise(Home_Fouls = sum(HF, na.rm = TRUE),
                  Away_Fouls = sum(AF, na.rm = TRUE))
      
      data$Foul_Diff <- (data$Away_Fouls - data$Home_Fouls) / 
        (data$Home_Fouls + data$Away_Fouls) * 100
      
      # Plot the percentage difference in fouls with a vertical line in the middle
      ggplot(data, aes(x = reorder(HOMETEAM, Foul_Diff), y = Foul_Diff)) +
        geom_bar(stat = "identity", aes(fill = Foul_Diff > 0), position = "identity") +
        coord_flip() +  # Flip the axes for horizontal bars
        geom_vline(xintercept = 0, linetype = "dashed", color = "black") +  # Vertical line at x = 0
        scale_fill_manual(values = c("red", "blue"), labels = c("Home Fouls More", "Away Fouls More")) +  # Red for Home fouls more, Blue for Away fouls more
        labs(title = "Percentage Difference in Fouls (Away vs Home) per Team",
             x = "Team",
             y = "Percentage Difference in Fouls (Away - Home)",
             fill = "Foul Diff") +
        theme_minimal()
      
    } else if (input$metric == "Yellow Cards") {
      data <- d.EPL %>%
        group_by(HOMETEAM) %>%
        summarise(Home_Yellow_Cards = sum(HY, na.rm = TRUE),
                  Away_Yellow_Cards = sum(AY, na.rm = TRUE))
      
      data$Yellow_Card_Diff <- (data$Away_Yellow_Cards - data$Home_Yellow_Cards) / 
        (data$Home_Yellow_Cards + data$Away_Yellow_Cards) * 100
      
      ggplot(data, aes(x = reorder(HOMETEAM, Yellow_Card_Diff), y = Yellow_Card_Diff)) +
        geom_bar(stat = "identity", aes(fill = Yellow_Card_Diff > 0), position = "identity") +
        coord_flip() +
        geom_vline(xintercept = 0, linetype = "dashed", color = "black") +
        scale_fill_manual(values = c("red", "blue"), labels = c("Home Cards More", "Away Cards More")) +
        labs(title = "Percentage Difference in Yellow Cards (Away vs Home) per Team",
             x = "Team",
             y = "Percentage Difference in Yellow Cards (Away - Home)",
             fill = "Card Diff") +
        theme_minimal()
      
    } else if (input$metric == "Red Cards") {
      data <- d.EPL %>%
        group_by(HOMETEAM) %>%
        summarise(Home_Red_Cards = sum(HR, na.rm = TRUE),
                  Away_Red_Cards = sum(AR, na.rm = TRUE))
      
      data$Red_Card_Diff <- (data$Away_Red_Cards - data$Home_Red_Cards) / 
        (data$Home_Red_Cards + data$Away_Red_Cards) * 100
      
      ggplot(data, aes(x = reorder(HOMETEAM, Red_Card_Diff), y = Red_Card_Diff)) +
        geom_bar(stat = "identity", aes(fill = Red_Card_Diff > 0), position = "identity") +
        coord_flip() +
        geom_vline(xintercept = 0, linetype = "dashed", color = "black") +
        scale_fill_manual(values = c("red", "blue"), labels = c("Home Cards More", "Away Cards More")) +
        labs(title = "Percentage Difference in Red Cards (Away vs Home) per Team",
             x = "Team",
             y = "Percentage Difference in Red Cards (Away - Home)",
             fill = "Card Diff") +
        theme_minimal()
    }
  })
}

# Run the Shiny app
shinyApp(ui = ui, server = server)




