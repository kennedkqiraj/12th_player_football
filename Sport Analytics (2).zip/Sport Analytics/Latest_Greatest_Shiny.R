library(shiny)
library(ggplot2)
library(dplyr)

# Load the data
d.EPL <- read.csv("Data/combined_data.csv")

# Convert DATE column to Date format
d.EPL$DATE <- as.Date(d.EPL$DATE, format = "%d/%m/%Y")

# Create a column to flag games with no crowd attendance
d.EPL$No_Crowd <- ifelse(
  (d.EPL$DATE >= as.Date("2020-06-17") & d.EPL$DATE <= as.Date("2020-07-26")) |  
    (d.EPL$DATE >= as.Date("2020-09-12") & d.EPL$DATE <= as.Date("2020-12-01")) |  
    (d.EPL$DATE >= as.Date("2020-12-17") & d.EPL$DATE <= as.Date("2021-05-16")),   
  TRUE, FALSE
)

# Create a column to flag games with limited crowd attendance
d.EPL$Limited_Crowd <- ifelse(
  (d.EPL$DATE >= as.Date("2020-12-02") & d.EPL$DATE <= as.Date("2020-12-16")) |  
    (d.EPL$DATE >= as.Date("2021-05-17") & d.EPL$DATE <= as.Date("2021-05-23")),   
  TRUE, FALSE
)

# Function to get teams present in both the "No Crowd" and "Limited Crowd" datasets
get_common_teams <- function() {
  no_crowd_teams <- d.EPL %>% filter(No_Crowd == TRUE | Limited_Crowd == TRUE) %>% pull(HOMETEAM) %>% unique()
  full_crowd_teams <- d.EPL %>% filter(No_Crowd == FALSE & Limited_Crowd == FALSE) %>% pull(HOMETEAM) %>% unique()
  return(intersect(no_crowd_teams, full_crowd_teams))
}

# Function to get referees involved during the "No Crowd" or "Limited Crowd" periods
get_common_referees <- function() {
  no_crowd_referees <- d.EPL %>% filter(No_Crowd == TRUE | Limited_Crowd == TRUE) %>% pull(REFEREE) %>% unique()
  return(no_crowd_referees)
}

# Shiny UI
ui <- fluidPage(
  titlePanel("EPL Stats Dashboard"),
  sidebarLayout(
    sidebarPanel(
      # Dropdown menu for selecting the metric to plot (includes Win Difference)
      selectInput(
        inputId = "metric", 
        label = "Select a metric to plot:", 
        choices = c("Yellow Cards", "Red Cards", "Fouls", "Win Difference"),
        selected = "Yellow Cards"
      ),
      
      # Toggle to switch between absolute and percentage difference
      radioButtons(
        inputId = "diff_type", 
        label = "Display Difference as:", 
        choices = c("Percentage (%)", "Absolute (n)"), 
        selected = "Percentage (%)"
      ),
      
      # Radio button to select between "TEAM" and "REFEREE"
      radioButtons(
        inputId = "group_by", 
        label = "Group By:", 
        choices = c("TEAM", "REFEREE"), 
        selected = "TEAM"
      ),
      
      width = 2  # Make the sidebar narrower
    ),
    mainPanel(
      fluidRow(
        column(6, plotOutput(outputId = "fullCrowdPlot")),  # Equal width for left plot
        column(6, plotOutput(outputId = "limitedCrowdPlot"))  # Equal width for right plot
      )
    )
  )
)

# Shiny Server
server <- function(input, output, session) {
  
  # Function to create the plot based on crowd conditions and the selected grouping (TEAM or REFEREE)
  generate_plot <- function(data, metric, title, diff_type, group_by) {
    # Group by either TEAM or REFEREE based on user input
    if (group_by == "TEAM") {
      group_var <- "HOMETEAM"
    } else {
      group_var <- "REFEREE"
    }
    
    # Filter data based on the metric and calculate number of games for each group (TEAM or REFEREE)
    if (metric == "Fouls") {
      data <- data %>%
        group_by(!!sym(group_var)) %>%
        summarise(Home_Value = sum(HF, na.rm = TRUE),
                  Away_Value = sum(AF, na.rm = TRUE),
                  Num_Games = n())
      
    } else if (metric == "Yellow Cards") {
      data <- data %>%
        group_by(!!sym(group_var)) %>%
        summarise(Home_Value = sum(HY, na.rm = TRUE),
                  Away_Value = sum(AY, na.rm = TRUE),
                  Num_Games = n())
      
    } else if (metric == "Red Cards") {
      data <- data %>%
        group_by(!!sym(group_var)) %>%
        summarise(Home_Value = sum(HR, na.rm = TRUE),
                  Away_Value = sum(AR, na.rm = TRUE),
                  Num_Games = n())
      
    } else if (metric == "Win Difference") {
      # Calculate home and away wins
      data <- data %>%
        group_by(!!sym(group_var)) %>%
        summarise(Home_Value = sum(FTR == "H", na.rm = TRUE),
                  Away_Value = sum(FTR == "A", na.rm = TRUE),
                  Num_Games = n())
    }
    
    # Calculate either percentage or absolute difference based on user selection
    if (diff_type == "Percentage (%)") {
      data <- data %>%
        mutate(Diff = (Away_Value - Home_Value) / (Home_Value + Away_Value) * 100)
    } else {
      data <- data %>%
        mutate(Diff = Away_Value - Home_Value)
    }
    
    # Calculate a reasonable position for the number of games
    data$Game_Label_Pos <- min(data$Diff, na.rm = TRUE) - 5  # Adjust the label position slightly to the left
    
    # Plot the result with the number of games displayed in brackets
    ggplot(data, aes(x = reorder(!!sym(group_var), -Diff), y = Diff)) +  # Sorting in descending order (-Diff)
      geom_bar(stat = "identity", aes(fill = Diff > 0), position = "identity") +
      geom_text(aes(label = paste0("(", Num_Games, ")"), y = Game_Label_Pos), 
                hjust = 1.5, size = 3.5, color = "black") +  # Display the number of games in brackets
      coord_flip() +
      geom_vline(xintercept = 0, linetype = "dashed", color = "black") +
      scale_fill_manual(values = c("TRUE" = "blue", "FALSE" = "red"),  # Map TRUE/FALSE to colors
                        labels = c("Home More", "Away More")) +         # Correct labels for legend
      labs(title = title,
           x = group_by,
           y = ifelse(diff_type == "Percentage (%)", "Percentage Difference", "Absolute Difference"),
           fill = "Difference") +  # Legend title
      theme_minimal() +
      theme(axis.text.y = element_text(hjust = 1)) +  # Keep team names or referees on the y-axis
      scale_y_continuous(expand = expansion(mult = c(0.15, 0.1)))  # Add more padding on the left to shift the graph to the right
  }
  
  # Render plot for full crowd with updated title
  output$fullCrowdPlot <- renderPlot({
    # Get common teams or referees based on the selection
    if (input$group_by == "TEAM") {
      common_teams <- get_common_teams()
      full_crowd_data <- d.EPL %>% filter(No_Crowd == FALSE & Limited_Crowd == FALSE & HOMETEAM %in% common_teams)
    } else {
      common_referees <- get_common_referees()
      full_crowd_data <- d.EPL %>% filter(No_Crowd == FALSE & Limited_Crowd == FALSE & REFEREE %in% common_referees)
    }
    generate_plot(full_crowd_data, input$metric, "Crowd Present", input$diff_type, input$group_by)
  })
  
  # Render plot for limited or no crowd with updated title
  output$limitedCrowdPlot <- renderPlot({
    # Get common teams or referees based on the selection
    if (input$group_by == "TEAM") {
      common_teams <- get_common_teams()
      limited_crowd_data <- d.EPL %>% filter((No_Crowd == TRUE | Limited_Crowd == TRUE) & HOMETEAM %in% common_teams)
    } else {
      common_referees <- get_common_referees()
      limited_crowd_data <- d.EPL %>% filter((No_Crowd == TRUE | Limited_Crowd == TRUE) & REFEREE %in% common_referees)
    }
    generate_plot(limited_crowd_data, input$metric, "Crowd Limited or Absent", input$diff_type, input$group_by)
  })
}

# Run the Shiny app
shinyApp(ui = ui, server = server)
                 