library(plyr)
library(readr)
library(dplyr)
library(data.table)
library(lubridate)
library(stringr)
library(ggplot2)
library(tidyr)

directory <- getwd()

convert_to_uppercase <- function(df) {
   colnames(df) <- toupper(colnames(df))
   return(df)
 }

# List all the files in the specified directory that start with "E" followed by digits
file_names <- list.files(path = directory, pattern ="*E*.*csv", full.names = TRUE)

#Read and convert files
file_names <- ldply(file_names, function(file) convert_to_uppercase(read_csv(file)))

d.EPL <- file_names[2:23]

# Save the d.EPL data frame as a CSV file
write.csv(d.EPL, file = "combined_data.csv", row.names = FALSE)
